package com.hd.morkchiven;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    RecyclerView myRecycleView;
    com.hd.morkchiven.RecyclerViewAdapter myRecycleViewAdpter;
    List<String> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       ViewAdapterPager viewPagerAdapter = new ViewAdapterPager(getSupportFragmentManager(),FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        ViewPager viewPager = findViewById(R.id.img_grid_view_main);
        viewPager.setAdapter(viewPagerAdapter);

         myRecycleView= findViewById(R.id.recycler_view);
        myRecycleViewAdpter = new com.hd.morkchiven.RecyclerViewAdapter(list);
        myRecycleView.setLayoutManager(new GridLayoutManager(this, 2));
        myRecycleView.setAdapter(myRecycleViewAdpter);
    }
}
