package com.hd.morkchiven;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

public class ViewAdapterPager  extends FragmentPagerAdapter {


    public ViewAdapterPager(@NonNull FragmentManager fm, int behavior) {
        super(fm, behavior);
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {

        switch (position){
            case 0 : return "Home";
            case 1 : return "Categories";
            case 2 : return  "Search";
            case 3 : return "Account";
        }
        return "Home";
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
              return new FragementHome();
            case 1:
                return new FragementCategories();
            case 2:
                return new FragementSearch();
            case 3:
                return  new FragementAccount();
        }
        return new FragementHome();
    }

    @Override
    public int getCount() {
        return 4;
    }
}
